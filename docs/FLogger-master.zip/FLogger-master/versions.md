# FLogger 1.0.2 发布  
2017-02-10  
### v1.0.2 版本包含以下改进和 bug 修复：  
#### 改进：  
* 无  

#### bug修复：  
* 修复不能自动创建多级目录的bug  

可下载文件已经发布到 [Maven Central Repository](http://repo1.maven.org/maven2/com/github/cyfonly/flogger/1.0.2/)。
  
  
# FLogger 1.0.1 发布
2017-02-06
### v1.0.1 版本包含以下改进和 bug 修复：
#### 改进：
* 新增输出到控制台的功能，方便开发调试。详情参看配置：  
```
# 是否输出到控制台(默认为false)
CONSOLE_PRINT = false
```
  
#### bug修复：
* 无 
  
可下载文件已经发布到 [Maven Central Repository](http://repo1.maven.org/maven2/com/github/cyfonly/flogger/1.0.1/)。
  
  
  
# FLogger 1.0.0 首次发布
2017-01-09  
可下载文件已经发布到 [Maven Central Repository](http://repo1.maven.org/maven2/com/github/cyfonly/flogger/1.0.0/)。
